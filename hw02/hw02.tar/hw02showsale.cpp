#include "hw02.hpp"

extern double totalCoffeeSold;

void showCoffeeSold() {
  cout << "Total Coffee Sold: " << totalCoffeeSold << " ounces." << endl << endl;
}
