#include "hw02.hpp"

extern double totalMoneyMade;

void showMoneyMade() {
  cout << "Total Money Made: " << totalMoneyMade << "$" << endl << endl;
}
