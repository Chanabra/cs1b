#ifndef myheader_h
#define myheader_h

//***********************************************
// CS1B - Dr. B - TTh 7:30-9:45pm
// Brandon Norman - HW #3 Income Tax Calculation
//***********************************************

#endif
